//
//  ViewController.swift
//  SAAMClient
//
//  Created by Xiaoyi Wang on 2020-02-21.
//  Copyright © 2020 SAAM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

